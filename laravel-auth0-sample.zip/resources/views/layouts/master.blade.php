<html>
<head>
    <title>Auth0 Sample</title>
</head>
<body>
<div class="container">
    @yield('content')
</div>
</body>
</html>