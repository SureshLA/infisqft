var AUTH0_CLIENT_ID='KNuydwEqwGsPNpxdAhACmOWDUmBEZsLn';
var AUTH0_DOMAIN='wptest.auth0.com';
var AUTH0_CALLBACK_URL=location.href;